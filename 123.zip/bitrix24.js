const axios = require('axios');

const BITRIX24_WEBHOOK = process.env.BITRIX24_WEBHOOK;

async function sendNotifications(taskId) {
  try {
    // Получаем ID чата задачи
    const taskResponse = await axios.get(`${BITRIX24_WEBHOOK}/tasks.task.get`, {
      params: { taskId, select: ['chatId'] },
    });
    const chatId = taskResponse.data.result.task.chatId;

    // Получаем список участников чата
    const chatUsersResponse = await axios.get(`${BITRIX24_WEBHOOK}/im.chat.user.list`, {
      params: { chatId },
    });
    const userIds = chatUsersResponse.data.result;

    // Отправляем уведомление каждому участнику
    for (const userId of userIds) {
      await axios.post(`${BITRIX24_WEBHOOK}/im.notify.personal.add`, {
        userId,
        message: `Новое сообщение в задаче №${taskId}.`,
      });
    }
  } catch (error) {
    console.error('Ошибка при отправке уведомлений:', error);
  }
}

module.exports = { sendNotifications };
