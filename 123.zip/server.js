const express = require('express');
const { sendNotifications } = require('./bitrix24');

const app = express();
app.use(express.json());

// Healthcheck для деплоя
app.get('/', (req, res) => {
  res.status(200).send('OK');
});

app.post('/bitrix24/webhook', async (req, res) => {
  try {
    const event = req.body;
    if (
      event.event === 'ONAFTERIMESSAGEADD' &&
      event.data?.CHAT_ENTITY_TYPE === 'TASKS_TASK'
    ) {
      const taskId = event.data.CHAT_ENTITY_ID;
      await sendNotifications(taskId);
    }
    res.status(200).send('ok');
  } catch (error) {
    console.error('Ошибка обработки вебхука:', error);
    res.status(500).send('error');
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Сервер запущен на порту ${PORT}`);
});
