curl -X POST https://vibecode.bitrix24.tech/v1/infra/servers \
  -H "X-Api-Key: vibe_api_4EQNyhrLJyuu9lgYHi77hIQL0BA2MxHn_a9a1cf" \
  -H "Content-Type: application/json" \
  -d '{
    "provider": "bitrix-cloud",
    "name": "my-app",
    "plan": "bc-small",
    "region": "ru-central1-b",
    "image": "fd83esfomhq25p2ono90"
  }'