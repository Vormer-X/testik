const BASE = 'https://vibecode.bitrix24.tech/v1'

async function api(method, path, body = null) {
    const opts = { method, headers: { 'X-Api-Key': 'vibe_api_4EQNyhrLJyuu9lgYHi77hIQL0BA2MxHn_a9a1cf' } }
    if (body) {
        opts.headers['Content-Type'] = 'application/json'
        opts.body = JSON.stringify(body)
    }
    const res = await fetch(`${BASE}${path}`, opts)
    if (!res.ok) throw new Error(`${method} ${path} → ${res.status}`)
    return res.json()
}
(async () => {
    // 1. Выбрать провайдера, тариф, регион, образ
    // const { data: plans } = await api('GET', '/infra/providers/bitrix-cloud/plans')
    // const { data: regions } = await api('GET', '/infra/providers/bitrix-cloud/regions')
    // const { data: images } = await api('GET', '/infra/providers/bitrix-cloud/images')
    // // console.log(images);
    // // console.log(regions);
    // // console.log(plans);

    // const plan = plans.find(p => p.id === 'bc-agent')
    // const region = regions.find(r => r.id === 'ru-central1-b')
    // const image = images[0]

    // // 2. Создать сервер (всегда в Black Hole)
    // const { data: server } = await api('POST', '/infra/servers', {
    //     provider: 'bitrix-cloud',
    //     name: 'my-crm-bot',
    //     plan: plan.id,
    //     region: region.id,
    //     image: image.id,
    // })
    // console.log(`Сервер создан: ${server.id}, субдомен: ${server.subdomain}`)
    // let info = server
    // while (info.status !== 'running' || info.blackholeStatus !== 'CONNECTED') {
    //     await new Promise(r => setTimeout(r, 10000)) // 10 секунд между опросами
    //     const res = await api('GET', `/infra/servers/${server.id}`)
    //     info = res.data
    //     console.log(`status=${info.status}, blackhole=${info.blackholeStatus}`)
    // }
    // 4. Задеплоить приложение(обязательно ? stream = false для JSON - ответа)
    const deploy = await api('POST', `/infra/servers/94d74668-e46d-498f-9c53-ec8e10f94f95/deploy?stream=false`, {
        source: { url: 'https://github.com/Vormer-X/testik/blob/main/task-notifier.tar.gz' },
        runtime: 'node20',
        install: 'cd /opt/app && npm install --production',
        preStart: 'cd /opt/app && npx prisma migrate deploy',
        start: 'cd /opt/app && node server.js',
        port: 3000,
        env: { NODE_ENV: 'production' },
    })
    console.log(deploy);
    

})()





// // 4. Задеплоить приложение (обязательно ?stream=false для JSON-ответа)
// const deploy = await api('POST', `/infra/servers/94d74668-e46d-498f-9c53-ec8e10f94f95/deploy?stream=false`, {
//   source: { url: 'https://github.com/Vormer-X/testik/blob/main/task-notifier.tar.gz' },
//   runtime: 'node20',
//   install: 'cd /opt/app && npm install --production',
//   preStart: 'cd /opt/app && npx prisma migrate deploy',
//   start: 'cd /opt/app && node server.js',
//   port: 3000,
//   env: { NODE_ENV: 'production' },
// })

// console.log(`Приложение живёт: ${deploy.data.appUrl}`)

// // 5. (Опционально) Настроить авто-сон через 60 минут простоя
// await api('PATCH', `/infra/servers/${server.id}/sleep`, { sleepAfterMinutes: 60 })